﻿using KeyifyClassLibrary.Core.MusicTheory.Enums;

namespace KeyifyClassLibrary.Core.MusicTheory.Tuning
{
    public interface ITuning
    {
        Note[] ReturnNotes();
    }
}