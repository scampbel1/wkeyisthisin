﻿using KeyifyClassLibrary.Core.MusicTheory.Enums;

namespace KeyifyClassLibrary.Core.MusicTheory
{
    public interface IScale
    {
        void AddNote(Note note);
    }
}