﻿namespace KeyifyClassLibrary.Core.MusicTheory.Enums
{
    public enum PentatonicModes
    {
        Minor,
        Major
    }
}