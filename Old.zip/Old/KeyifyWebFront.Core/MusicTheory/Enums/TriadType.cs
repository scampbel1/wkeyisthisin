﻿using System.Diagnostics.CodeAnalysis;

namespace KeyifyClassLibrary.Core.MusicTheory.Enums
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public enum TriadType
    {
        m,
        M,
        o,
        aug
    }
}