﻿using System;

namespace KeyifyWebClient.Core.Models
{
    public class SelectedNoteItem
    {
        public String Note { get; set; }
        public bool Selected { get; set; }
    }
}